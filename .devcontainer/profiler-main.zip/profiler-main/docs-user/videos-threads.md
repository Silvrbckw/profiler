# Multiple threads and async code

Walk through the steps of understanding and looking at a multi-process profile.

<div class='youtube'><iframe src="https://www.youtube-nocookie.com/embed/Qq0h1veSBEc?rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>
