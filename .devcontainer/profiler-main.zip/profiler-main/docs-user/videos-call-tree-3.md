# Call Tree (Part 3) - Branching

Real code branches and this demonstration walk you through how call trees are affected by branching and show how to understand them in a simplified code example.

<div class='youtube'><iframe src="https://www.youtube-nocookie.com/embed/3hoceL8d4YM?rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>
