# Call Tree (Part 2) - Real recording

Take the theory of call stack and call trees to the interface of the Firefox Profiler.

<div class='youtube'><iframe src="https://www.youtube-nocookie.com/embed/jqhP_25Nl-c?rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>
