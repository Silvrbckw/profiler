* [Firefox Profiler](https://profiler.firefox.com/)
* [GitHub](https://github.com/firefox-devtools/profiler)
* [*Firefox Profiler* on Matrix](https://chat.mozilla.org/#/room/#profiler:mozilla.org)
