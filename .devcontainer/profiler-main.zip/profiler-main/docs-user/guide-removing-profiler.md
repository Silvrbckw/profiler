# Removing profiler
To remove the Firefox Profiler from the toolbar, right-click on the Profiler icon and choose "Remove from Toolbar" in the context menu.

The Firefox Profiler is built in Firefox. The icon is only a menu button (that you can remove). There is no need and no way to remove the whole Firefox Profiler.
