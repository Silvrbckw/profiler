# Samples and markers

Profilers have two main different types of data they collect. Thinking of the profile in terms of samples and markers is a useful way to understand what is going on with the underlying data.

<div class='youtube'><iframe src="https://www.youtube-nocookie.com/embed/BBDErudR_8Q?rel=0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>
