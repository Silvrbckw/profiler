// @flow
module.exports = {
  hostname: 'localhost',
};
