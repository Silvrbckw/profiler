These icons come from https://simpleicons.org/.
