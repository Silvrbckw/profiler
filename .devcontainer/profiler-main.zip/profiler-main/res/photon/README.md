# Photon Stylings

This area is a styling area for photon components. See it at [profiler.firefox.com/photon/](https://profiler.firefox.com/photon/).
